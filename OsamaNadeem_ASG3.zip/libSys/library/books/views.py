from django.shortcuts import render
from .models import Book, Author, BookInstance, Genre


