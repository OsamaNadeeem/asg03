After running the server, go to http://127.0.0.1:8000/admin/.
User credentials for login:

Name: osama
password: asdasdasd

github: https://github.com/OsamaNadeeem/asg03